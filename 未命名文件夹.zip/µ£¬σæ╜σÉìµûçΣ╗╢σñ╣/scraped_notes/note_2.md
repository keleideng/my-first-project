**Author:** 00-
**Image:** https://via.placeholder.com/380x480.png/000000/FFFFFF?text=Note+2
**URL:** https://www.xiaohongshu.com/explore/6837c416000000002202b736?xsec_token=ABHWawNCI2NyNQvX0aU0prxmsaJXXZEQIlM3Zd9efntkU=&xsec_source=pc_search
**Tags:** #原相机, #实况, #女大学生, #eyepony小露珠

---

# 发哪张给crush比较好呀ᜊ˚⌯> × 𖦹⌯˚ᜊ

**Body:**
好纠结。。每一张都喜欢。。

---

### Comments
- **00- (作者)**: 眼猪猪是eyepony小露珠，妈生小黑瞳超级自然~
- **潮流**: hk
- **小红薯6674232C**: 你不许跟他说话！
- **好win**: 2222222
- **Keke**: 他凭什么当你crush 