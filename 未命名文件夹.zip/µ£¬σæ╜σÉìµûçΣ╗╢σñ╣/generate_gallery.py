import os
import re
import html

# A self-contained, robust HTML template with your desired UI styles and a responsive Flexbox layout.
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>小红书笔记画廊 - 美女大学生</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap');
        body {
            font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
                'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 40px;
        }
        .gallery-title {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 40px;
        }
        .gallery-container {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        .note-card {
            width: 380px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s, box-shadow 0.3s;
            max-height: 85vh;
            flex: 1 1 350px;
            max-width: 400px;
        }
        .note-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
        }
        .note-image {
            height: 480px;
            background-color: #000;
            overflow: hidden;
            flex-shrink: 0;
        }
        .note-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .note-content {
            padding: 20px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            overflow-y: auto;
        }
        .note-content::-webkit-scrollbar { width: 6px; }
        .note-content::-webkit-scrollbar-track { background: #f1f1f1; }
        .note-content::-webkit-scrollbar-thumb { background: #ccc; border-radius: 3px; }
        .note-content::-webkit-scrollbar-thumb:hover { background: #aaa; }
        .author-info {
            display: flex;
            align-items: center;
            margin-bottom: 16px;
            flex-shrink: 0;
        }
        .author-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: #e0e0e0;
            margin-right: 12px;
        }
        .author-name { font-weight: 500; font-size: 14px; }
        .note-body { margin-bottom: 12px; }
        .note-body h1 { font-size: 17px; margin: 0; font-weight: 700; line-height: 1.4; }
        .note-body a { color: inherit; text-decoration: none; }
        .note-body a:hover { color: #d9304f; }
        .note-body-content { font-size: 14px; margin-top: 8px; line-height: 1.6; color: #555; white-space: pre-wrap; }
        .note-author { font-size: 12px; color: #888; margin-top: 10px; }
        .note-footer { padding: 15px; border-top: 1px solid #eee; }
        .note-tags { margin-bottom: 12px; }
        .note-tags .tag {
            display: inline-block;
            background-color: #f0f2f5;
            padding: 3px 10px;
            border-radius: 12px;
            margin-right: 6px;
            margin-bottom: 6px;
            color: #555;
            font-size: 12px;
        }
        hr { border: none; border-top: 1px solid #eeeeee; margin: 15px 0; }
        .comments-section { flex-grow: 1; }
        .comments-section h3 { font-size: 13px; color: #999; font-weight: 500; margin-bottom: 12px; }
        .comment { display: flex; margin-bottom: 12px; font-size: 13px; }
        .comment-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background-color: #f0f0f0;
            margin-right: 10px;
            flex-shrink: 0;
        }
        .comment-body { display: flex; flex-direction: column; }
        .comment-author { font-weight: 500; color: #888; margin-bottom: 3px; }
        .comment-text { line-height: 1.5; color: #333; }
    </style>
</head>
<body>
    <h1 class="gallery-title">小红书笔记画廊 - 美女大学生</h1>
    <div class="gallery-container">
        <!-- %%NOTES_GALLERY%% -->
    </div>
</body>
</html>
"""

def parse_md_file(filepath):
    """A robust, line-by-line parser for the specific .md note format."""
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    note = {
        'title': '无标题',
        'author': '未知作者',
        'body': '',
        'tags': [],
        'comments': [],
        'url': '#'
    }

    mode = 'meta' # Modes: meta, title, body, comments
    body_lines = []

    for line in lines:
        stripped_line = line.strip()

        if stripped_line.startswith('**Author:**'):
            note['author'] = stripped_line.replace('**Author:**', '').strip()
        elif stripped_line.startswith('**URL:**'):
            note['url'] = stripped_line.replace('**URL:**', '').strip()
        elif stripped_line.startswith('**Tags:**'):
            tags_str = stripped_line.replace('**Tags:**', '').strip()
            if tags_str:
                note['tags'] = [tag.strip() for tag in tags_str.split(',') if tag.strip()]
        elif stripped_line == '---':
            if mode == 'meta':
                mode = 'title'
            elif mode == 'body':
                mode = 'comments'
        elif stripped_line.startswith('# ') and mode == 'title':
            note['title'] = stripped_line.replace('# ', '').strip()
        elif stripped_line.startswith('**Body:**') and mode == 'title':
            mode = 'body'
        elif mode == 'body' and stripped_line:
            body_lines.append(stripped_line)
        elif stripped_line == '### Comments':
            mode = 'comments'
        elif mode == 'comments' and (stripped_line.startswith('- ') or stripped_line.startswith('* ')):
            comment_content = stripped_line[2:]
            author_match = re.match(r'\*\*(.*?)\*\*:\s*(.*)', comment_content)
            if author_match:
                author, text = author_match.groups()
                note['comments'].append({'author': author.strip(), 'text': text.strip()})

    note['body'] = '\\n'.join(body_lines)
    return note

def generate_html_from_notes(notes, output_path):
    """Generates the final HTML from note data and the embedded template."""
    cards_html = ""
    for i, note in enumerate(notes, 1):
        title = html.escape(note['title'])
        author = html.escape(note['author'])
        url = html.escape(note['url'])
        body = html.escape(note['body']).replace('\\n', '<br>')
        image_text = html.escape(f"Note {i}")

        tags_html = ''.join(f'<span class="tag">{html.escape(tag)}</span>' for tag in note['tags'])
        
        comments_html = ""
        for comment in note['comments']:
            comment_author = html.escape(comment['author'])
            comment_text = html.escape(comment['text'])
            comments_html += f'''
            <div class="comment">
                <div class="comment-avatar"></div>
                <div class="comment-body">
                    <div class="comment-author">{comment_author}</div>
                    <div class="comment-text">{comment_text}</div>
                </div>
            </div>
            '''

        card_template = f'''
        <!-- Note -->
        <div class="note-card">
            <div class="note-image"><img src="https://via.placeholder.com/380x480.png/000000/FFFFFF?text={image_text}" alt="{html.escape(note['title'])}"></div>
            <div class="note-content">
                <div class="author-info">
                    <div class="author-avatar"></div>
                    <div class="author-name">{author}</div>
                </div>
                <div class="note-body">
                    <a href="{url}" target="_blank"><h1>{title}</h1></a>
                    <p class="note-body-content">{body}</p>
                </div>
                <div class="note-author">{author}</div>
                <div class="note-footer">
                    <div class="note-tags">{tags_html}</div>
                    <div class="note-comments">
                        <h3>Comments</h3>
                        {comments_html}
                    </div>
                </div>
            </div>
        </div>
        '''
        cards_html += card_template

    final_html = HTML_TEMPLATE.replace('<!-- %%NOTES_GALLERY%% -->', cards_html)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(final_html)

def main():
    """Main function to find notes and generate the gallery."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        notes_dir = os.path.join(script_dir, 'scraped_notes')
        output_path = os.path.join(script_dir, 'notes_gallery.html')

        if not os.path.isdir(notes_dir):
            print(f"错误: 笔记目录 '{notes_dir}' 不存在。请先创建该目录并放入.md文件。")
            # Create an empty gallery page if the directory doesn't exist
            final_html = HTML_TEMPLATE.replace('<!-- %%NOTES_GALLERY%% -->', '<h2 style="text-align:center;">笔记目录不存在</h2>')
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(final_html)
            return

        md_files = sorted([f for f in os.listdir(notes_dir) if f.endswith('.md')])
        
        if not md_files:
            print(f"警告: 在 '{notes_dir}' 中没有找到 .md 文件。")
            final_html = HTML_TEMPLATE.replace('<!-- %%NOTES_GALLERY%% -->', '<h2 style="text-align:center;">没有找到任何笔记。</h2>')
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(final_html)
            return

        all_notes = []
        for md_file in md_files:
            filepath = os.path.join(notes_dir, md_file)
            note_data = parse_md_file(filepath)
            if note_data:
                all_notes.append(note_data)
            else:
                print(f"警告: 无法正确解析文件 '{md_file}'，已跳过。")

        generate_html_from_notes(all_notes, output_path)

        print(f"成功生成 '{output_path}'，包含 {len(all_notes)} 篇笔记。")
    
    except Exception as e:
        print(f"生成过程中发生意外错误: {e}")

if __name__ == '__main__':
    main() 